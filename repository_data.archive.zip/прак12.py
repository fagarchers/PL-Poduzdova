import tkinter as tk
from tkinter import messagebox
import json
import requests
def getting_repository_data():
    repository = entry.get()
    if not repository:
        messagebox.showerror('ошибка')
        return

    url = f'https://api.github.com/repos/{repository}'
    try:
        answer = requests.get(url)
        answer.raise_for_status()
        data = answer.json()
        finding = {'company': data.get('company'), 'created_at': data.get('created_at'), 'email': data.get('email'), 'id': data.get('id'), 'name': data.get('name'), 'url': data.get('url')}
                   
        filename = f"{repository.replace('/', ' ')}_data.json"
        with open(filename, 'w') as file:
                   json.dump(finding, file)
        messagebox.showinfo('данные успешно сохранены в файл')
    except requests.exceptions.RequestException as e:
        messagebox.showerror("Ошибка", f"Ошибка при запросе: {e}")
    except json.JSONDecodeError:
        messagebox.showerror("Ошибка", "Не удалось разобрать ответ сервера")

window = tk.Tk()
window.title('Github information')
tk.Label(window, text='введите название репозитория:').pack()
entry = tk.Entry(window, width=50)
entry.pack()
button = tk.Button(window, text='получить данные', command=getting_repository_data)
button.pack()
window.mainloop()

                   
                   
                   
        
    
